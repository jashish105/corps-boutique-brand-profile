import { useState, useEffect } from 'react'

const NAV_ITEMS = [
  { label: 'Proposition', href: 'proposition' },
  { label: 'Facility', href: 'facility' },
  { label: 'Operations', href: 'operations' },
  { label: 'Members', href: 'members' },
  { label: 'Developer Value', href: 'developer' },
  { label: 'Vision', href: 'vision' },
]

const ARCHETYPES = [
  {
    id: 'professional',
    title: 'THE PROFESSIONAL',
    roles: ['Executives', 'Consultants', 'Corporate professionals', 'Senior management', 'Doctors', 'Lawyers', 'Finance professionals'],
    useCase: 'Early morning training, post-work training, personal training, recovery and networking.',
  },
  {
    id: 'founder',
    title: 'THE FOUNDER',
    roles: ['Entrepreneurs', 'Business owners', 'Startup founders', 'Investors', 'Independent professionals'],
    useCase: 'Training before work, flexible daytime visits, meetings, community and networking.',
  },
  {
    id: 'athlete',
    title: 'THE ATHLETE',
    roles: ['Performance-focused members', 'Runners', 'HYROX participants', 'Strength athletes', 'Endurance athletes'],
    useCase: 'Frequent training, structured programming, performance development and recovery.',
  },
  {
    id: 'creative',
    title: 'THE CREATIVE',
    roles: ['Creators', 'Designers', 'Artists', 'Media professionals', 'Creative entrepreneurs'],
    useCase: 'Training, community, informal meetings and lifestyle-led engagement.',
  },
  {
    id: 'performance',
    title: 'THE PERFORMANCE MEMBER',
    roles: ['High personal training investment', 'Recovery & wellness regulars', 'Sports performance devotees', 'Nutrition & biometric users'],
    useCase: 'A premium integrated destination instead of multiple disconnected providers.',
  },
]

const DAY_FLOW = [
  { time: 'Early Morning', activities: ['Training', 'Personal training', 'Strength & conditioning', 'Running & endurance'] },
  { time: 'Morning', activities: ['Independent training', 'Recovery', 'Coffee', 'Member meetings'] },
  { time: 'Midday', activities: ['Personal training', 'Recovery', 'Flexible work', 'Wellness sessions'] },
  { time: 'Afternoon', activities: ['Training', 'Small-group sessions', 'Recovery', 'Community activity'] },
  { time: 'Evening', activities: ['Peak training', 'Group classes', 'Run club', 'Performance sessions'] },
  { time: 'Late Evening', activities: ['Recovery', 'Member socialising', 'Events', 'Hospitality'] },
]

const DEVELOPER_VALUES = [
  { num: '01', title: 'DESTINATION CREATION', body: 'CORPS becomes a reason for people to specifically visit the property — not merely a service within it.' },
  { num: '02', title: 'PREMIUM POSITIONING', body: 'A high-quality human performance destination adds a premium lifestyle component, positioning the property around fitness, wellness, performance and community.' },
  { num: '03', title: 'RECURRING FOOTFALL', body: 'Fitness is a high-frequency category. Members visit multiple times every week, generating substantially more recurring activity than conventional commercial uses.' },
  { num: '04', title: 'LONGER DWELL TIME', body: 'Training leads to recovery, coffee, meetings, community and social interaction — increasing the time members spend within the property.' },
  { num: '05', title: 'ALL-DAY UTILISATION', body: 'Activity distributed across multiple periods of the day rather than concentrated into one peak, complementing every other commercial use within the development.' },
  { num: '06', title: 'COMMUNITY GENERATION', body: 'Professionals, founders, athletes and creatives form a community. That community becomes an asset to the surrounding development.' },
  { num: '07', title: 'BRAND VALUE', body: 'CORPS operates as a destination brand rather than a generic gym. The property becomes associated with a distinctive lifestyle and consumer demographic.' },
]

const ARCHETYPE_IMAGES: Record<string, string> = {
  professional: 'https://images.unsplash.com/photo-1757924284732-4189190321cf?w=600&h=800&fit=crop&auto=format',
  founder: 'https://images.unsplash.com/photo-1758957646695-ec8bce3df462?w=600&h=800&fit=crop&auto=format',
  athlete: 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?w=600&h=800&fit=crop&auto=format',
  creative: 'https://images.unsplash.com/photo-1746046889599-79db184c8ea3?w=600&h=800&fit=crop&auto=format',
  performance: 'https://images.unsplash.com/photo-1722925541142-5db2668ca492?w=600&h=800&fit=crop&auto=format',
}

export default function App() {
  const [activeArchetype, setActiveArchetype] = useState('professional')
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  const current = ARCHETYPES.find((a) => a.id === activeArchetype)!

  return (
    <div className="bg-background text-foreground min-w-0">
      {/* NAV */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'bg-background/96 backdrop-blur-sm border-b border-border' : 'bg-transparent'
        }`}
      >
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-4 flex items-center justify-between gap-8">
          <span
            className="text-sm tracking-[0.25em] text-primary font-black uppercase flex-shrink-0"
            style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
          >
            CORPS BOUTIQUE
          </span>
          <div className="hidden lg:flex items-center gap-7">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.href}
                onClick={() => scrollTo(item.href)}
                className="text-[11px] tracking-[0.18em] text-muted-foreground hover:text-foreground transition-colors duration-200 uppercase"
              >
                {item.label}
              </button>
            ))}
          </div>
          <span className="text-[11px] tracking-[0.18em] text-muted-foreground uppercase flex-shrink-0 hidden sm:block">
            Gurugram · 2026
          </span>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="relative h-screen flex flex-col justify-end overflow-hidden bg-black">
        <img
          src="https://images.unsplash.com/photo-1757924284732-4189190321cf?w=1920&h=1080&fit=crop&auto=format"
          alt="CORPS BOUTIQUE performance floor — modern gym with full-height windows"
          className="absolute inset-0 w-full h-full object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />

        <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10 pb-16 lg:pb-24 w-full">
          <p className="text-[11px] tracking-[0.35em] text-primary uppercase mb-5">
            Property &amp; Operating Proposal
          </p>
          <h1
            style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.88 }}
            className="text-[clamp(72px,13vw,188px)] font-black uppercase text-foreground mb-10 lg:mb-14"
          >
            CORPS<br />BOUTIQUE
          </h1>
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-10">
            <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
              A premium human performance destination designed for the urban, affluent consumer who demands more than a conventional gym.
            </p>
            <div className="flex gap-7 sm:gap-10">
              {['PERFORMANCE', 'WELLNESS', 'COMMUNITY', 'DESTINATION'].map((word) => (
                <div key={word} className="text-right">
                  <div className="w-px h-7 bg-primary mb-2 ml-auto" />
                  <span className="text-[10px] tracking-[0.2em] text-primary">{word}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 01 PROPOSITION ── */}
      <section id="proposition" className="py-24 lg:py-36 border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-6 mb-16 lg:mb-24">
            <div className="col-span-12 lg:col-span-1">
              <span
                className="text-primary text-sm tracking-[0.2em]"
                style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
              >
                01
              </span>
            </div>
            <div className="col-span-12 lg:col-span-5">
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(42px,5.5vw,72px)] font-black uppercase mb-0"
              >
                THE<br />PROPOSITION
              </h2>
            </div>
            <div className="col-span-12 lg:col-span-6 flex items-end">
              <p className="text-sm text-muted-foreground leading-relaxed max-w-lg">
                CORPS BOUTIQUE operates as a premium human performance, fitness and wellness destination — designed specifically for an urban, affluent customer who wants more than a conventional gym. The result is not a fitness tenant. It is a destination business designed to generate recurring visits throughout the day.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 border-t border-border">
            {[
              {
                title: 'PERFORMANCE',
                desc: 'Strength training, conditioning, endurance, functional training and athletic development.',
              },
              {
                title: 'RECOVERY',
                desc: 'Recovery, mobility, stretching and performance-support services.',
              },
              {
                title: 'WELLNESS',
                desc: 'Lifestyle-led wellness experiences integrated into the member journey.',
              },
              {
                title: 'COMMUNITY',
                desc: 'Running clubs, performance events, workshops, social gatherings and member-led activities.',
              },
              {
                title: 'HOSPITALITY',
                desc: 'A premium environment where members spend time before and after training, meet people and work informally.',
              },
            ].map((pillar, i) => (
              <div
                key={pillar.title}
                className={`p-7 lg:p-8 border-b sm:border-r border-border ${i === 4 ? 'lg:border-r-0' : ''} ${i >= 3 ? 'sm:border-b-0' : ''} group hover:bg-card transition-colors duration-300`}
              >
                <div className="w-6 h-px bg-primary mb-5 transition-all duration-300 group-hover:w-12" />
                <h3
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className="text-base font-black uppercase tracking-widest mb-3 text-foreground"
                >
                  {pillar.title}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{pillar.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 02 FACILITY ── */}
      <section id="facility" className="py-24 lg:py-36 border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-8 lg:gap-16 items-start">
            <div className="col-span-12 lg:col-span-6 order-2 lg:order-1">
              <div className="flex items-center gap-5 mb-10">
                <span
                  className="text-primary text-sm tracking-[0.2em] flex-shrink-0"
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                >
                  02
                </span>
                <div className="flex-1 h-px bg-border" />
              </div>
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(38px,4.5vw,60px)] font-black uppercase mb-10"
              >
                WHAT WE ARE<br />BUILDING
              </h2>

              <div className="grid grid-cols-2 gap-px bg-border">
                {[
                  {
                    title: 'PERFORMANCE FLOOR',
                    items: ['Strength training', 'Functional training', 'Conditioning', 'Endurance', 'HYROX training', 'Personal training', 'Small-group training', 'Mobility & movement'],
                  },
                  {
                    title: 'RECOVERY ZONE',
                    items: ['Recovery programming', 'Mobility area', 'Stretching', 'Performance recovery', 'Post-training services'],
                  },
                  {
                    title: 'COMMUNITY & LIFESTYLE',
                    items: ['Member lounge', 'Coffee experience', 'Run club', 'Workshops', 'Performance events', 'Member gatherings'],
                  },
                  {
                    title: 'OUTDOOR / TERRACE',
                    items: ['Outdoor training', 'Run-club meetups', 'Yoga & mobility', 'Community events', 'Brand activations'],
                  },
                ].map((zone) => (
                  <div key={zone.title} className="bg-card p-5 lg:p-7">
                    <h4
                      style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                      className="text-[10px] font-black uppercase tracking-widest text-primary mb-4"
                    >
                      {zone.title}
                    </h4>
                    <ul className="space-y-1.5">
                      {zone.items.map((item) => (
                        <li key={item} className="text-xs text-muted-foreground flex items-start gap-2">
                          <span className="w-1 h-1 bg-primary rounded-full flex-shrink-0 mt-1.5" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>

            <div className="col-span-12 lg:col-span-6 order-1 lg:order-2 lg:sticky lg:top-24">
              <div className="relative overflow-hidden bg-muted" style={{ aspectRatio: '4/5' }}>
                <img
                  src="https://images.unsplash.com/photo-1722925541142-5db2668ca492?w=900&h=1125&fit=crop&auto=format"
                  alt="Athlete training with barbell on CORPS performance floor"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-7 left-7 right-7">
                  <p className="text-[10px] tracking-[0.25em] text-primary uppercase mb-1.5">The Performance Floor</p>
                  <p className="text-xs text-foreground/75 leading-relaxed">Where athletic development meets precision training.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 03 ALL-DAY OPERATIONS ── */}
      <section id="operations" className="py-24 lg:py-36 border-b border-border bg-card">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-6 mb-16 lg:mb-20">
            <div className="col-span-12 lg:col-span-1">
              <span
                className="text-primary text-sm tracking-[0.2em]"
                style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
              >
                03
              </span>
            </div>
            <div className="col-span-12 lg:col-span-5">
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(38px,4.5vw,60px)] font-black uppercase"
              >
                AN ALL-DAY<br />DESTINATION
              </h2>
            </div>
            <div className="col-span-12 lg:col-span-6 flex items-end">
              <p className="text-sm text-muted-foreground leading-relaxed max-w-md">
                A conventional gym is a morning and evening business. CORPS is designed as an all-day destination — creating reasons for people to enter the property throughout the day, not only during traditional gym peak hours.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-px bg-border">
            {DAY_FLOW.map((slot) => (
              <div key={slot.time} className="bg-background p-6 lg:p-7 group hover:bg-card transition-colors duration-300">
                <div className="w-2 h-2 bg-primary rounded-full mb-4 group-hover:scale-125 transition-transform duration-300" />
                <h4
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className="text-[10px] font-black uppercase tracking-widest text-primary mb-4"
                >
                  {slot.time}
                </h4>
                <ul className="space-y-2">
                  {slot.activities.map((act) => (
                    <li key={act} className="text-xs text-muted-foreground leading-relaxed">
                      {act}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 04 MEMBER ARCHETYPES ── */}
      <section id="members" className="py-24 lg:py-36 border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-6 mb-14 lg:mb-20">
            <div className="col-span-12 lg:col-span-1">
              <span
                className="text-primary text-sm tracking-[0.2em]"
                style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
              >
                04
              </span>
            </div>
            <div className="col-span-12 lg:col-span-11">
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(38px,4.5vw,60px)] font-black uppercase mb-4"
              >
                WHO WILL COME
              </h2>
              <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
                CORPS is positioned toward a premium urban customer. The archetypes below turn member profiles into an actual property-footfall strategy.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-px bg-border">
            {/* Tab list */}
            <div className="col-span-12 lg:col-span-4 bg-background flex flex-row lg:flex-col overflow-x-auto">
              {ARCHETYPES.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setActiveArchetype(a.id)}
                  className={`text-left px-6 py-5 transition-colors duration-200 border-b border-border flex-shrink-0 lg:flex-shrink-1 ${
                    activeArchetype === a.id
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background text-muted-foreground hover:bg-card hover:text-foreground'
                  }`}
                >
                  <span
                    style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                    className="text-xs font-black uppercase tracking-widest whitespace-nowrap"
                  >
                    {a.title}
                  </span>
                </button>
              ))}
            </div>

            {/* Detail panel */}
            <div className="col-span-12 lg:col-span-4 bg-card p-8 lg:p-10">
              <div className="w-8 h-px bg-primary mb-8" />
              <h3
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-4xl lg:text-5xl font-black uppercase mb-8 text-foreground"
              >
                {current.title}
              </h3>
              <ul className="space-y-3 mb-10">
                {current.roles.map((role) => (
                  <li key={role} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="w-1 h-1 bg-primary rounded-full flex-shrink-0" />
                    {role}
                  </li>
                ))}
              </ul>
              <div className="border-t border-border pt-8">
                <p className="text-[10px] tracking-[0.2em] text-primary uppercase mb-3">Use Case</p>
                <p className="text-sm text-foreground/75 leading-relaxed">{current.useCase}</p>
              </div>
            </div>

            {/* Image */}
            <div className="col-span-12 lg:col-span-4 overflow-hidden bg-muted" style={{ minHeight: '380px' }}>
              <img
                src={ARCHETYPE_IMAGES[activeArchetype]}
                alt={`${current.title} at CORPS BOUTIQUE`}
                className="w-full h-full object-cover transition-opacity duration-500"
                style={{ minHeight: '380px' }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* ── FULL-WIDTH QUOTE BREAK ── */}
      <section className="relative h-[45vh] min-h-[300px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1746046889599-79db184c8ea3?w=1920&h=800&fit=crop&auto=format"
          alt="CORPS BOUTIQUE community run — athletes competing in urban marathon"
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-black/20" />
        <div className="relative z-10 h-full flex items-center">
          <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
            <p className="text-[10px] tracking-[0.35em] text-primary uppercase mb-4">The Community</p>
            <blockquote
              style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.9 }}
              className="text-[clamp(30px,5.5vw,70px)] font-black uppercase text-foreground max-w-2xl"
            >
              "A PLACE COMMUNITIES FORM."
            </blockquote>
          </div>
        </div>
      </section>

      {/* ── 05 FOOTFALL MODEL ── */}
      <section className="py-24 lg:py-36 border-b border-border bg-card">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-6 mb-16 lg:mb-20">
            <div className="col-span-12 lg:col-span-1">
              <span
                className="text-primary text-sm tracking-[0.2em]"
                style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
              >
                05
              </span>
            </div>
            <div className="col-span-12 lg:col-span-11">
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(38px,4.5vw,60px)] font-black uppercase mb-4"
              >
                THE FOOTFALL MODEL
              </h2>
              <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
                Repeat visitation rather than occasional footfall. Multiple weekly touchpoints across training, recovery, community and events.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-px bg-border">
            {[
              { label: 'PRIMARY', sublabel: 'Members', desc: 'Recurring high-frequency users who form the base business.' },
              { label: 'SECONDARY', sublabel: 'Guests', desc: 'Member guests, trial users, prospective members and event participants.' },
              { label: 'PROGRAMMING', sublabel: 'Community', desc: 'Participants attending run clubs, workshops, challenges and performance events.' },
              { label: 'PARTNER', sublabel: 'Professionals & Brands', desc: 'Coaches, wellness professionals, sports brands, nutrition partners and event collaborators.' },
              { label: 'EVENT', sublabel: 'Special Events', desc: 'Performance events, community runs, workshops, launches and brand activations.' },
            ].map((type, i) => (
              <div key={type.label} className="bg-background p-7 lg:p-8 group hover:bg-muted transition-colors duration-300">
                <div
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className="text-5xl font-black text-border group-hover:text-primary/15 transition-colors duration-300 mb-5"
                >
                  {String(i + 1).padStart(2, '0')}
                </div>
                <div className="w-5 h-px bg-primary mb-4" />
                <h4
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className="text-[10px] font-black uppercase tracking-widest text-primary mb-1"
                >
                  {type.label}
                </h4>
                <h5 className="text-sm font-medium text-foreground mb-4">{type.sublabel}</h5>
                <p className="text-xs text-muted-foreground leading-relaxed">{type.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 07 VALUE TO DEVELOPER ── */}
      <section id="developer" className="py-24 lg:py-36 border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-6 mb-16 lg:mb-24">
            <div className="col-span-12 lg:col-span-1">
              <span
                className="text-primary text-sm tracking-[0.2em]"
                style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
              >
                07
              </span>
            </div>
            <div className="col-span-12 lg:col-span-11">
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(38px,4.5vw,60px)] font-black uppercase"
              >
                VALUE TO THE DEVELOPER
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
            {DEVELOPER_VALUES.map((val) => (
              <div key={val.num} className="bg-background p-8 lg:p-10 group hover:bg-card transition-colors duration-300">
                <div className="flex items-start justify-between mb-8">
                  <span
                    style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                    className="text-6xl font-black text-muted/20 group-hover:text-primary/15 transition-colors duration-300"
                  >
                    {val.num}
                  </span>
                  <div className="w-4 h-px bg-primary mt-5" />
                </div>
                <h3
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className="text-base font-black uppercase tracking-wide mb-4 text-foreground"
                >
                  {val.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{val.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 14 LONG-TERM VISION ── */}
      <section id="vision" className="py-24 lg:py-36 border-b border-border bg-card">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-12 gap-6 mb-16 lg:mb-24">
            <div className="col-span-12 lg:col-span-1">
              <span
                className="text-primary text-sm tracking-[0.2em]"
                style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
              >
                14
              </span>
            </div>
            <div className="col-span-12 lg:col-span-5">
              <h2
                style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.92 }}
                className="text-[clamp(38px,4.5vw,60px)] font-black uppercase"
              >
                THE LONG-TERM<br />OPPORTUNITY
              </h2>
            </div>
            <div className="col-span-12 lg:col-span-6 flex items-end">
              <p className="text-sm text-muted-foreground leading-relaxed max-w-md">
                CORPS begins with the physical club. It grows into a broader human performance ecosystem — connecting physical, digital and performance science into one coherent destination. For this property, the priority is clear.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-px bg-border mb-20">
            {[
              { stage: '01', title: 'PHYSICAL CLUB', items: ['Training', 'Recovery', 'Community', 'Events'], active: true },
              { stage: '02', title: 'DIGITAL PLATFORM', items: ['Member experience', 'Training', 'Recovery', 'Community'], active: false },
              { stage: '03', title: 'PERFORMANCE SCIENCE', items: ['Data', 'Technology', 'Performance optimisation'], active: false },
            ].map((stage) => (
              <div key={stage.stage} className={`p-8 lg:p-12 ${stage.active ? 'bg-primary' : 'bg-background'}`}>
                <span
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className={`text-6xl lg:text-8xl font-black block mb-6 ${stage.active ? 'text-primary-foreground/15' : 'text-muted/15'}`}
                >
                  {stage.stage}
                </span>
                <h4
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className={`text-xs font-black uppercase tracking-widest mb-6 ${stage.active ? 'text-primary-foreground' : 'text-foreground'}`}
                >
                  {stage.title}
                </h4>
                <ul className="space-y-2.5">
                  {stage.items.map((item) => (
                    <li
                      key={item}
                      className={`text-sm flex items-center gap-2 ${stage.active ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}
                    >
                      <span
                        className={`w-1 h-1 rounded-full flex-shrink-0 ${stage.active ? 'bg-primary-foreground/50' : 'bg-primary'}`}
                      />
                      {item}
                    </li>
                  ))}
                </ul>
                {!stage.active && (
                  <div className="mt-8 pt-6 border-t border-border">
                    <span className="text-[10px] text-muted-foreground/50 tracking-widest uppercase">Expansion Phase</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="text-center py-6">
            <p
              style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 1.05 }}
              className="text-[clamp(24px,4vw,52px)] font-black uppercase text-foreground"
            >
              BUILD THE CLUB.&nbsp;
              <span className="text-primary">BUILD THE COMMUNITY.</span>&nbsp;
              CREATE THE DESTINATION.
            </p>
          </div>
        </div>
      </section>

      {/* ── CLOSE ── */}
      <section className="relative min-h-screen flex flex-col justify-between overflow-hidden bg-black pt-24 pb-16">
        <img
          src="https://images.unsplash.com/photo-1775993167276-743bbcde77e1?w=1920&h=1080&fit=crop&auto=format"
          alt="CORPS BOUTIQUE — premium gym performance space"
          className="absolute inset-0 w-full h-full object-cover opacity-15"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black" />

        <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10 w-full">
          <div className="w-10 h-px bg-primary mb-12 lg:mb-20" />
          <h2
            style={{ fontFamily: "'Big Shoulders Display', sans-serif", lineHeight: 0.88 }}
            className="text-[clamp(52px,10vw,140px)] font-black uppercase text-foreground"
          >
            LET'S BUILD<br />THE<br />DESTINATION.
          </h2>
        </div>

        <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-10 w-full">
          <div className="h-px bg-border mb-12" />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-end">
            <div>
              <p className="text-sm text-muted-foreground leading-8 max-w-sm">
                A place where people train.<br />
                A place where people recover.<br />
                A place where people meet.<br />
                A place where communities form.<br />
                A place people return to several times every week.<br />
                <span className="text-foreground/60">A place that gives the property a reason for people to come.</span>
              </p>
            </div>
            <div className="lg:text-right">
              <div className="inline-block text-left lg:text-right">
                <div className="w-10 h-px bg-primary mb-6 lg:ml-auto" />
                <p
                  style={{ fontFamily: "'Big Shoulders Display', sans-serif" }}
                  className="text-xl font-black uppercase tracking-widest text-foreground mb-1"
                >
                  ASHISH JAIN
                </p>
                <p className="text-xs tracking-[0.2em] text-muted-foreground uppercase">
                  Founder, CORPS BOUTIQUE
                </p>
                <p className="text-xs tracking-[0.2em] text-primary uppercase mt-1.5">Gurugram · 2026</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
